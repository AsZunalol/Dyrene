import Navbar from "@/components/Navbar";

export default function CraftingPage() {
  return (
    <div className="min-h-screen bg-[#07203a] text-white">
      <Navbar />

      <div className="pt-24 text-center">
        <h1 className="text-3xl font-bold">Crafting</h1>
      </div>
    </div>
  );
}